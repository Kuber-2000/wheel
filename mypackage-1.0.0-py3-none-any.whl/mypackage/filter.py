#importing modules
from pyspark.sql.functions import *

#function 
class Filter:
    def filter_Transformation(Input_df,Condition):
        Output_df = Input_df.filter(Condition)
        return Output_df